﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace PROG2A_POE_Ismail_Yusuf_Omar_19331746.Core
{
    public class ObservableObject : INotifyPropertyChanged //call INotifyPropertyChanged EventHandler
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
