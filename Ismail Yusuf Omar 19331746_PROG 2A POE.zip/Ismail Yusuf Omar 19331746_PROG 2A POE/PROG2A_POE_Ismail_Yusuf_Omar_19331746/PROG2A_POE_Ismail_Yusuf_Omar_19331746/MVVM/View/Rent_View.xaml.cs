﻿using System.Windows.Controls;

namespace PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.View
{
    /// <summary>
    /// Interaction logic for Rent_View.xaml
    /// </summary>
    public partial class Rent_View : UserControl
    {
        public Rent_View()
        {
            InitializeComponent();
        }

        private void tb_Rent_TextChanged(object sender, TextChangedEventArgs e)
        {//if value in textbox returns Validation error disable button
            TextBox tb = sender as TextBox;
            btn1.IsEnabled = Validation.GetHasError(tb) == false ? true : false;
        }
    }
}
