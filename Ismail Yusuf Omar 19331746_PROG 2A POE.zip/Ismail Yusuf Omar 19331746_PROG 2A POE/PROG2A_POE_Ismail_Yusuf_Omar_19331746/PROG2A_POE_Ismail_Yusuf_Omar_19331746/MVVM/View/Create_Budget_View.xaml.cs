﻿using System.Windows;
using System.Windows.Controls;

namespace PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.View
{
    /// <summary>
    /// Interaction logic for Create_Budget_View.xaml
    /// </summary>
    public partial class Create_Budget_View : UserControl
    {
        public Create_Budget_View()
        {
            InitializeComponent();
        }

        private void Btn_Buy_Property_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Btn_Rent_Property_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Btn_No_Vehicle_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Btn_Yes_Vehicle_Checked(object sender, RoutedEventArgs e)
        {

        }



        private void Btn_CreateBudget_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Btn_Yes_Save_Checked(object sender, RoutedEventArgs e)
        {  //when checked change Visibility of following objects
            save_Prompt.Visibility = Visibility.Visible;
            save_Cal.Visibility = Visibility.Visible;
            save_Amount.Visibility = Visibility.Visible;
            cb_Image.Visibility = Visibility.Hidden;

        }

        private void Btn_No_Save_Checked_1(object sender, RoutedEventArgs e)
        {//when checked change Visibility of following objects
            save_Prompt.Visibility = Visibility.Hidden;
            save_Cal.Visibility = Visibility.Hidden;
            save_Amount.Visibility = Visibility.Hidden;
            cb_Image.Visibility = Visibility.Visible;
        }

        private void save_Amount_TextChanged(object sender, TextChangedEventArgs e)
        { //if value in textbox returns Validation error disable button
            TextBox tb = sender as TextBox;
            Btn_CreateBudget.IsEnabled = Validation.GetHasError(tb) == false ? true : false;
        }
    }
}
