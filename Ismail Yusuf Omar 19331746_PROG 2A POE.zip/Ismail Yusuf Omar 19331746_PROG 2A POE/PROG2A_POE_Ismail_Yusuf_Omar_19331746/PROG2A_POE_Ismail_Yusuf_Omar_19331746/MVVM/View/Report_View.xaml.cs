﻿using System.Windows.Controls;

namespace PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.View
{
    /// <summary>
    /// Interaction logic for Report_View.xaml
    /// </summary>
    public partial class Report_View : UserControl
    {
        public Report_View()
        {
            InitializeComponent();
        }


    }
}
