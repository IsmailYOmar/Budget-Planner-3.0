﻿using System.Windows;
using System.Windows.Controls;

namespace PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.View
{
    /// <summary>
    /// Interaction logic for Vehicle_View.xaml
    /// </summary>
    public partial class Vehicle_View : UserControl
    {
        public Vehicle_View()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void tb_Vehicle_Make_TextChanged(object sender, TextChangedEventArgs e)
        {//if value in textbox returns Validation error disable button
            TextBox tb = sender as TextBox;
            btn1.IsEnabled = Validation.GetHasError(tb) == false ? true : false;
        }

        private void tb_Vehicle_Model_TextChanged(object sender, TextChangedEventArgs e)
        {//if value in textbox returns Validation error disable button
            TextBox tb = sender as TextBox;
            btn1.IsEnabled = Validation.GetHasError(tb) == false ? true : false;
        }

        private void tb_Vehicle_Price_TextChanged(object sender, TextChangedEventArgs e)
        {//if value in textbox returns Validation error disable button
            TextBox tb = sender as TextBox;
            btn1.IsEnabled = Validation.GetHasError(tb) == false ? true : false;
        }

        private void tb_Vehicle_Deposit_TextChanged(object sender, TextChangedEventArgs e)
        {//if value in textbox returns Validation error disable button
            TextBox tb = sender as TextBox;
            btn1.IsEnabled = Validation.GetHasError(tb) == false ? true : false;
        }

        private void tb_Vehicle_Interest_TextChanged(object sender, TextChangedEventArgs e)
        {//if value in textbox returns Validation error disable button
            TextBox tb = sender as TextBox;
            btn1.IsEnabled = Validation.GetHasError(tb) == false ? true : false;
        }

        private void tb_Vehicle_Insurance_TextChanged(object sender, TextChangedEventArgs e)
        {//if value in textbox returns Validation error disable button
            TextBox tb = sender as TextBox;
            btn1.IsEnabled = Validation.GetHasError(tb) == false ? true : false;
        }
    }
}
