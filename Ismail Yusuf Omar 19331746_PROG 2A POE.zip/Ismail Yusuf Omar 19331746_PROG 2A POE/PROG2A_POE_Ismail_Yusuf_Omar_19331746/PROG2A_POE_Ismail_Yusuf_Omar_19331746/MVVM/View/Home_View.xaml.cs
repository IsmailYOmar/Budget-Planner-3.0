﻿using System.Windows;
using System.Windows.Controls;

namespace PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.View
{
    /// <summary>
    /// Interaction logic for Home_View.xaml
    /// </summary>
    public partial class Home_View : UserControl
    {
        public Home_View()
        {
            InitializeComponent();
        }

        private void Button_Budget_Click(object sender, RoutedEventArgs e)
        {//when home view create button budget clicked set rd_Budget_ as check
         //to change collor of button in nav bar 
            foreach (Window window in Application.Current.Windows)
            {
                if (window.GetType() == typeof(MainWindow))
                {
                    (window as MainWindow).rd_Budget_.IsChecked = true;
                }
            }
        }
    }
}
