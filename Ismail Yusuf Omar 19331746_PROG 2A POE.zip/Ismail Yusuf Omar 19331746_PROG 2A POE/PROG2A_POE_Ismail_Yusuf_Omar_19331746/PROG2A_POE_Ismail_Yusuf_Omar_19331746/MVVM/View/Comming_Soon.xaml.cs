﻿using System.Windows.Controls;

namespace PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.View
{
    /// <summary>
    /// Interaction logic for Comming_Soon.xaml
    /// </summary>
    public partial class Comming_Soon : UserControl
    {
        public Comming_Soon()
        {
            InitializeComponent();
        }
    }
}
