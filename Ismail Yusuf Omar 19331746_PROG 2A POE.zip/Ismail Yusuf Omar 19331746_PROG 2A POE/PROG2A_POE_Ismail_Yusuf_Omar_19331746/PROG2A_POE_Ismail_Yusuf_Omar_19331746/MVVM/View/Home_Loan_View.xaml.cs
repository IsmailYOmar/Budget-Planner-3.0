﻿using System.Windows.Controls;

namespace PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.View
{
    /// <summary>
    /// Interaction logic for Home_Loan_View.xaml
    /// </summary>
    public partial class Home_Loan_View : UserControl
    {
        public Home_Loan_View()
        {
            InitializeComponent();
        }

        private void tb_Property_Price_TextChanged(object sender, TextChangedEventArgs e)
        {//if value in textbox returns Validation error disable button
            TextBox tb = sender as TextBox;
            btn1.IsEnabled = Validation.GetHasError(tb) == false ? true : false;
        }

        private void tb_Property_Deposit_TextChanged(object sender, TextChangedEventArgs e)
        {//if value in textbox returns Validation error disable button
            TextBox tb = sender as TextBox;
            btn1.IsEnabled = Validation.GetHasError(tb) == false ? true : false;
        }

        private void tb_Property_Interest_TextChanged(object sender, TextChangedEventArgs e)
        {//if value in textbox returns Validation error disable button
            TextBox tb = sender as TextBox;
            btn1.IsEnabled = Validation.GetHasError(tb) == false ? true : false;
        }

        private void tb_Property_Repay_TextChanged(object sender, TextChangedEventArgs e)
        {//if value in textbox returns Validation error disable button
            TextBox tb = sender as TextBox;
            btn1.IsEnabled = Validation.GetHasError(tb) == false ? true : false;
        }
    }
}
