﻿using System.Windows;
using System.Windows.Controls;

namespace PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.View
{
    /// <summary>
    /// Interaction logic for Expenses_View.xaml
    /// </summary>
    public partial class Expenses_View : UserControl
    {
        public Expenses_View()
        {
            InitializeComponent();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void tb_Gross_Income_TextChanged(object sender, TextChangedEventArgs e)
        {//if value in textbox returns Validation error disable button
            TextBox tb = sender as TextBox;
            btn1.IsEnabled = Validation.GetHasError(tb) == false ? true : false;
        }

        private void tb_Tax_TextChanged(object sender, TextChangedEventArgs e)
        {//if value in textbox returns Validation error disable button
            TextBox tb = sender as TextBox;
            btn1.IsEnabled = Validation.GetHasError(tb) == false ? true : false;
        }

        private void tb_Groceries_TextChanged(object sender, TextChangedEventArgs e)
        {//if value in textbox returns Validation error disable button
            TextBox tb = sender as TextBox;
            btn1.IsEnabled = Validation.GetHasError(tb) == false ? true : false;
        }

        private void tb_Water_Lights_TextChanged(object sender, TextChangedEventArgs e)
        {//if value in textbox returns Validation error disable button
            TextBox tb = sender as TextBox;
            btn1.IsEnabled = Validation.GetHasError(tb) == false ? true : false;
        }

        private void tb_Travel_TextChanged(object sender, TextChangedEventArgs e)
        {//if value in textbox returns Validation error disable button
            TextBox tb = sender as TextBox;
            btn1.IsEnabled = Validation.GetHasError(tb) == false ? true : false;
        }

        private void tb_Phone_TextChanged(object sender, TextChangedEventArgs e)
        {//if value in textbox returns Validation error disable button
            TextBox tb = sender as TextBox;
            btn1.IsEnabled = Validation.GetHasError(tb) == false ? true : false;
        }

        private void tb_Other_TextChanged(object sender, TextChangedEventArgs e)
        {//if value in textbox returns Validation error disable button
            TextBox tb = sender as TextBox;
            btn1.IsEnabled = Validation.GetHasError(tb) == false ? true : false;
        }
    }
}
