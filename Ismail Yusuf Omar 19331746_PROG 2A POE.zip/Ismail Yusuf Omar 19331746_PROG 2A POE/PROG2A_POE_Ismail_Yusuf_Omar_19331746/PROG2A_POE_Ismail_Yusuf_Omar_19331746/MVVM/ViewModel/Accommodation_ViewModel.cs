﻿using PROG2A_POE_Ismail_Yusuf_Omar_19331746.Core;
using PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.Model;

namespace PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.ViewModel
{
    public class Accommodation_ViewModel : ObservableObject // inherit ObservableObject and INotifyPropertyChanged methods
    {

        public Accommodation_ViewModel(Expenses Get_Expenses, Property Get_Property) 
        {
            this.Get_Expenses = Get_Expenses; //initalize parameters
            this.Get_Property = Get_Property;
        }

        //define constructors 
        private Expenses expenses;
        public Expenses Get_Expenses 
        {
            get { return expenses; }
            set
            {
                expenses = value;
                OnPropertChanged();
            }
        }

        private Property property;
        public Property Get_Property
        {
            get { return property; }
            set
            {
                property = value;
                OnPropertChanged();
            }
        }
    }
}


