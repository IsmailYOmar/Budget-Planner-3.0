﻿using PROG2A_POE_Ismail_Yusuf_Omar_19331746.Core;
using PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.Model;

namespace PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.ViewModel
{
    public class Vehicle_ViewModel : ObservableObject // inherit ObservableObject and INotifyPropertyChanged methods
    {

        public Vehicle_ViewModel(Expenses Get_Expenses, Vehicle Get_Vehicle)
        {
            this.Get_Expenses = Get_Expenses; //initalize parameters
            this.Get_Vehicle = Get_Vehicle;
        }

        //define constructors 
        private Expenses expenses;
        public Expenses Get_Expenses
        {
            get { return expenses; }
            set
            {
                expenses = value;
                OnPropertChanged();
            }
        }

        private Vehicle get_vehicle;
        public Vehicle Get_Vehicle
        {
            get { return get_vehicle; }
            set
            {
                get_vehicle = value;
                OnPropertChanged();
            }
        }
    }
}
