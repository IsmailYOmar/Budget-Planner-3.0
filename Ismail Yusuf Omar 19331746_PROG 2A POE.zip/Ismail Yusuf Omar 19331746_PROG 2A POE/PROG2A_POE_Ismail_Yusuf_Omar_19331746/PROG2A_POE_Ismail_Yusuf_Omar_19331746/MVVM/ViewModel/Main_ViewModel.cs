﻿using PROG2A_POE_Ismail_Yusuf_Omar_19331746.Core;
using PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.Model;
using System.Windows;

namespace PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.ViewModel
{
    class Main_ViewModel : ObservableObject //INotifyPropertyChanged methods
    {
        #region Declaring Relay Commands
        public RelayCommand Home_Command { get; set; }
        public RelayCommand Create_Command { get; set; }
        public RelayCommand Expenses_Command { get; set; }
        public RelayCommand Accommodation_Command { get; set; }
        public RelayCommand Home_Loan_Command { get; set; }
        public RelayCommand Home_Loan_HomeView_Command { get; set; }
        public RelayCommand Rent_Command { get; set; }
        public RelayCommand Vehicle_Yes_Command { get; set; }
        public RelayCommand Vehicle_No_Command { get; set; }
        public RelayCommand Vehicle_Command { get; set; }
        public RelayCommand Vehicle_HomeView_Command { get; set; }
        public RelayCommand Report_Command { get; set; }
        public RelayCommand Save_Yes_Command { get; set; }
        public RelayCommand Save_No_Command { get; set; }
        #endregion

        #region Declaring ViewModels
        public Home_ViewModel Home_VM { get; set; }
        public Create_Budget_ViewModel Create_Budget_VM;
        public Expenses_ViewModel Expenses_VM { get; set; }
        public Accommodation_ViewModel Accommodation_VM { get; set; }
        public Rent_ViewModel Rent_VM { get; set; }
        public Vehicle_ViewModel Vehicle_VM { get; set; }
        public Report_ViewModel Report_VM { get; set; }
        public Comming_Soon_ViewModel Soon_VM { get; set; }
        #endregion

        private object current_View; // object current_View will be equal to the current view

        public object Current_View // get and set method for object current_View that will update on property change using INotifyPropertyChanged
        {
            get { return current_View; }
            set
            {
                current_View = value;
                OnPropertChanged();
            }
        }
       
        #region Page Testers  
        // nullable bool values used to test which page to open
        bool? home_loan;
        bool? rent;
        bool? vehicle;
        bool? save;
        // get and set methodes for nullable bool values
        bool? from_Home;
        public bool? Home_loan
        {
            set
            {
                home_loan = value;
                OnPropertChanged();
            }
            get { return home_loan; }
        }
        public bool? Rent
        {
            set
            {
                rent = value;
                OnPropertChanged();
            }
            get { return rent; }
        }
        public bool? Vehicle
        {
            set
            {
                vehicle = value;
                OnPropertChanged();
            }
            get { return vehicle; }
        }
        public bool? From_Home
        {
            set
            {
                from_Home = value;
                OnPropertChanged();
            }
            get { return from_Home; }
        }
        #endregion

        public static double gross_Income; //public static gross income used testing delegate function

        public static void Total_Exceed_Income(double check_Total) 
        {
            //recevies vaule from delegate. check if value os greater than 75% of income

            if (check_Total >= (gross_Income * 0.75))
            {
                MessageBox.Show("Your total expenses is greater than 75% of your gross income.\n" +
                "Your total expenses are currently equal to " + check_Total.ToString("R0.##") + " your gross income is currently equal to " +
                gross_Income.ToString("R0.##"),"Caution");

            }
        }

        #region Declare Models 
        //models and there get and set methods
        private Expenses expenses;
        public Expenses Get_Expenses
        {
            get { return expenses; }
            set
            {
                expenses = value;
                OnPropertChanged();
            }
        }

        private Property property;
        public Property Get_Property
        {
            get { return property; }
            set
            {
                property = value;
                OnPropertChanged();
            }
        }

        private Vehicle get_vehicle;
        public Vehicle Get_Vehicle
        {
            get { return get_vehicle; }
            set
            {
                get_vehicle = value;
                OnPropertChanged();
            }
        }
        #endregion

        public Main_ViewModel()
        {
            #region Call Constuctors 
            Expenses Get_Expenses = new();
            Property Get_Property = new();
            Vehicle Get_Vehicle = new();
            #endregion

            Home_VM = new Home_ViewModel();//call Home_ViewModel into memory 
            Soon_VM = new Comming_Soon_ViewModel(); // call Comming_Soon_ViewModel into memory 
            Current_View = Home_VM; // set object Current_View to Home_ViewModel at start of program 

            #region Defing Relay Commands 
            /// <summary>
            ///  Below are all relay commands that will be called when user clicks a button.
            ///  These commands hold part of the data validation aswell as call calculation 
            ///  methods 
            /// </summary>
            Home_Command = new RelayCommand(o =>
            {
                Current_View = Home_VM; //when command is called set object Current_View to Home_ViewModel
            });
            Create_Command = new RelayCommand(o =>
            {
                Reset(); //sets all Page Tester values to null 
                Get_Expenses.Reset();  //sets all values in Expenses models equal to 0
                Get_Property.Reset();  //sets all values in Property models equal to 0
                Get_Vehicle.Reset();  //sets all values in Vehicle models equal to 0

                Create_Budget_VM = new Create_Budget_ViewModel(Get_Expenses); //call Create_Budget_ViewModel into memory and pass through Get_Expenses
                Current_View = Create_Budget_VM; //when command is called set object Current_View to Create_Budget_ViewModel

            });

            Expenses_Command = new RelayCommand(o =>
            {
                #region Create_Budget_VM Validation 
                #region Validation when user wants to save money 
                if (save.Equals(true))
                {
                    if (Get_Expenses.End_Date < System.DateTime.Now) //checks selected date is in the future
                    {
                        MessageBox.Show("Please choose a date that is in the future or valid.", "Error!");//display error
                        Current_View = Create_Budget_VM; //if error remain on page 
                        return;
                    }
                    else if (Get_Expenses.Save <= 0) // save amount is not negative or = 0
                    {
                        MessageBox.Show("Please enter a valid save amount.", "Error!");//display error
                        Current_View = Create_Budget_VM;//if error remain on page 
                        return;
                    }
                    else 
                    {
                        Get_Expenses.Save_Monthly(Get_Expenses.Save, Get_Expenses.End_Date); //if all true save to expense_List
                    }

                }
                #endregion

                if (vehicle is null || home_loan is null || rent is null || save is null)//makes sure all options are checked 
                {
                    MessageBox.Show("Please check all the options.", "Error!");//display error
                    Current_View = Create_Budget_VM;//if error remain on page 
                    return;
                }
                #endregion
                //if no errors call Expenses_ViewModel and set Current_View to be Expenses_ViewModel
                Expenses_VM = new Expenses_ViewModel(Get_Expenses);
                Current_View = Expenses_VM;
            });
            #region Relay commads for when user selects Buy or Rent 
            //These relay commands change the Page Tester Values when called
            // Used to determine if program shoul open Rent_VM or Home_Loan_VM
            Home_Loan_Command = new RelayCommand(o =>
            {
                Home_loan = true;
                Rent = false;
            });
            Rent_Command = new RelayCommand(o =>
            {
                Rent = true;
                Home_loan = false;
            });
            #endregion

            Accommodation_Command = new RelayCommand(o =>
            {
                #region Expenses_VM Validation
                if (Get_Expenses.Gross_Income <= 0) //Income cant be negative
                {
                    MessageBox.Show("Income can not be equal to 0 or negative", "Error!");//display error
                    Current_View = Expenses_VM;//if error remain on page 
                    return;
                }
                if (Get_Expenses.Tax > Get_Expenses.Gross_Income) // Tax cant greater than Incom
                {
                    MessageBox.Show("Tax can not be greater than Income.", "Error!");//display error
                    Current_View = Expenses_VM;//if error remain on page 
                    return;
                }
                gross_Income = Get_Expenses.Gross_Income;
                #endregion
                //if no errors check if Home_loan or Rent is true 
                if (Home_loan.Equals(true))
                {
                    Accommodation_VM = new Accommodation_ViewModel(Get_Expenses, Get_Property); //call Accommodation_ViewModel
                    Current_View = Accommodation_VM; // when Home_loan display Accommodation_VM

                }
                else if (Rent.Equals(true))
                {
                    Rent_VM = new Rent_ViewModel(Get_Expenses); //call Rent_ViewModel
                    Current_View = Rent_VM;// when Rent display Rent_VM
                }
            });


            #region Relay Commands for Vehicle Yes or No
            Vehicle_Yes_Command = new RelayCommand(o =>
            {
                Vehicle = true; //when command called Vehicle is true

            });
            Vehicle_No_Command = new RelayCommand(o =>
            {
                Vehicle = false;//when command called Vehicle is false
            });
            #endregion
            Vehicle_Command = new RelayCommand(o =>
            {
                #region Home_loan Validation
                if (Home_loan.Equals(true))
                {
                    if (Get_Property.Purchase_Price <= 0)//Purchase_Price can not be 0 are negative
                    {
                        MessageBox.Show("Purchase price can not be equal to 0 or negative", "Error!"); // dispaly message
                        Current_View = Accommodation_VM; //if error remain on page
                        return;
                    }
                    if (Get_Property.Deposit > Get_Property.Purchase_Price)//Deposit can not be greater than Purchase_Price
                    {
                        MessageBox.Show("Deposit can not be greater than Purchase Price.", "Error!");// dispaly message
                        Current_View = Accommodation_VM;//if error remain on page
                        return;
                    }
                    if (Get_Property.Interest_Rate <= 0)//Interest_Rate cant be 0
                    {
                        MessageBox.Show("Interest rate can not be equal to 0 or negative", "Error!");// dispaly message
                        Current_View = Accommodation_VM;//if error remain on page
                        return;
                    }
                    if (Get_Property.Repay_Months < 240 || Get_Property.Repay_Months > 360) //Repay_Months months must be between 
                    {
                        MessageBox.Show("Repay Months must be between 240 and 360 months", "Error!");// dispaly message
                        Current_View = Accommodation_VM;//if error remain on page
                        return;
                    }
                    #endregion
                    //if no errors proceed to home loan Calculations
                    #region Home_loan Calculations
                    Get_Property.Home_Loan(); //call method to calculate Home_Loan
                    if (Get_Property.Home_Loan() > Get_Expenses.Gross_Income / 3) //if Home_Loan is unlikely
                    {
                        //display YesNO message 
                        if (MessageBox.Show("With your current monthly income a home loan for this property is unlikely." +
                            "\nWould you like you try a loan on a different property.", "Error!", MessageBoxButton.YesNo).Equals(MessageBoxResult.Yes))
                        {
                            Current_View = Accommodation_VM;
                            return; // if user selects yes remain on page
                        }
                        else
                        {
                            return; //if user selects no return 
                        }
                    }
                    Get_Expenses.Living = Get_Property.Get_Home_Loan; //after validation save to expense_List
                    #endregion
                }
                #region Rent Validation 
                if (Rent.Equals(true))
                {
                    if (Get_Expenses.Rent <= 0) //rent can not be 0 are negative
                    {
                        MessageBox.Show("Rent can not be less than 0", "Error!"); //display message
                        Current_View = Rent_VM; //if error remain on page
                        return;
                    }
                }
                #endregion

                if (Vehicle.Equals(true)) //check if vehicle was selected 
                {
                    Vehicle_VM = new Vehicle_ViewModel(Get_Expenses, Get_Vehicle);//call Vehicle_ViewModel
                    Current_View = Vehicle_VM;//set Current_View equal to Vehicle_VM
                }
                else if (From_Home.Equals(true)) //when user opens Accommodation_VM from home page display 
                {
                    Current_View = Soon_VM; //extra page to be implemented that allows the user to only 
                                            //calculate a home loan 
                }
                else //if vehicle was not selected open Report_VM
                {
                    Get_Expenses.Get_Sum(Total_Exceed_Income); //call delgate function
                    Report_VM = new Report_ViewModel(Get_Expenses, Get_Property, Get_Vehicle);// call Report_VM
                    Current_View = Report_VM;
                }
            });


            Report_Command = new RelayCommand(o =>
            {
                #region Vehicle Validation
                if (Vehicle.Equals(true))
                {
                    if (Get_Vehicle.Price <= 0)
                    {
                        MessageBox.Show("Purchase price can not be equal to 0 or negative", "Error!");// dispaly message
                        Current_View = Vehicle_VM;//if error remain on page
                        return;
                    }
                    if (Get_Vehicle.Deposit > Get_Vehicle.Price)//Deposit can not be greater than Purchase_Price
                    {
                        MessageBox.Show("Deposit can not be greater than Purchase Price ", "Error!");// dispaly message
                        Current_View = Vehicle_VM;//if error remain on page
                        return;
                    }
                    if (Get_Vehicle.Interest <= 0)//Interest_Rate cant be 0
                    {
                        MessageBox.Show("Interest rate can not be equal to 0 or negative", "Error!");// dispaly message
                        Current_View = Vehicle_VM;//if error remain on page
                        return;
                    }
                }
                #endregion
                if (From_Home.Equals(true)) //when user opens Vehicle_VM from home page display 
                {
                    Current_View = Soon_VM; //extra page to be implemented that allows the user to only 
                                            //calculate a vehicle loan
                }
                //if no errors 
                Get_Vehicle.Monthly_Cost(); // call method to calculate Monthly_Cost of Vehicle
                Get_Expenses.Vehicle = Get_Vehicle.Get_Monthly_Cost; //save Vehicle Monthly_Cost to expense_List
                Get_Expenses.Get_Sum(Total_Exceed_Income);// call delegate function
                Report_VM = new Report_ViewModel(Get_Expenses, Get_Property, Get_Vehicle); //call Report_ViewModel 
                Current_View = Report_VM;

            });

            #region Home Button commands
            Home_Loan_HomeView_Command = new RelayCommand(o =>
            {
                Current_View = Soon_VM;//extra page to be implemented that allows the user to only 
                                       //calculate a home loan
                From_Home = true;
            });
            Vehicle_HomeView_Command = new RelayCommand(o =>
            {
                Current_View = Soon_VM;//extra page to be implemented that allows the user to only 
                                       //calculate a vehicle loa
                From_Home = true;
            });
            #endregion

            #region Relay commands for when user selects save money montly
            Save_Yes_Command = new RelayCommand(o =>
            {
                save = true;

            });
            Save_No_Command = new RelayCommand(o =>
            {
                save = false;

            });
            #endregion

            #endregion
        }

        #region Rest values
        public void Reset() //method to reset all Main_ViewModel values when user creates new budget 
        { //sets page testers equal to null
            home_loan = null;
            rent = null;
            vehicle = null;
            save = null;
            gross_Income = 0;
        }
        #endregion
    }
}

