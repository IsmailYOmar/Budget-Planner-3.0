﻿using PROG2A_POE_Ismail_Yusuf_Omar_19331746.Core;
using PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.Model;

namespace PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.ViewModel
{
    public class Create_Budget_ViewModel : ObservableObject // inherit ObservableObject and INotifyPropertyChanged methods
    {
        public Create_Budget_ViewModel(Expenses get_Expenses)
        {
            Get_Expenses = get_Expenses; //initalize parameters
        }


        public Expenses Get_Expenses { get; } //define constructors 


    }
}
