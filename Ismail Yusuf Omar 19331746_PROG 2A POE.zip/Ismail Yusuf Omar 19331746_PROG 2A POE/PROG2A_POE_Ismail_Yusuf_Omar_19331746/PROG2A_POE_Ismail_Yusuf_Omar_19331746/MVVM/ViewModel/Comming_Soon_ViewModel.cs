﻿namespace PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.ViewModel
{
    class Comming_Soon_ViewModel
    {
    }
}
