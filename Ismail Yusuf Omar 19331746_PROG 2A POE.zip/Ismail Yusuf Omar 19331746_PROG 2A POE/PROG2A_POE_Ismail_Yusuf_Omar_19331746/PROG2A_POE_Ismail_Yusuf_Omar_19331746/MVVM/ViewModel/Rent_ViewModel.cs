﻿using PROG2A_POE_Ismail_Yusuf_Omar_19331746.Core;
using PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.Model;

namespace PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.ViewModel
{

    public class Rent_ViewModel : ObservableObject  // inherit ObservableObject and INotifyPropertyChanged methods
    {
        public Rent_ViewModel(Expenses get_Expenses) //initalize parameters
        {
            Get_Expenses = get_Expenses;
        }
        //define constructors 
        public Expenses Get_Expenses { get; }
    }
}
