﻿using PROG2A_POE_Ismail_Yusuf_Omar_19331746.Core;
using PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.Model;
using System.Collections.Generic;
using System.Linq;

namespace PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.ViewModel
{
    public class Report_ViewModel : ObservableObject  // inherit ObservableObject and INotifyPropertyChanged methods
    {
        public Report_ViewModel(Expenses Get_Expenses, Property Get_Property, Vehicle Get_Vehicle)
        {
            this.Get_Expenses = Get_Expenses; //initalize parameters
            this.Get_Property = Get_Property;
            this.Get_Vehicle = Get_Vehicle;
            GetAll(); // call get all method
        }

        //define constructors 
        public Expenses Get_Expenses { get; }
        public Property Get_Property { get; }
        public Vehicle Get_Vehicle { get; }

        public Dictionary<string, double> GetAll() //orders expenses_List by descending
        {
            Get_Expenses.expenses_List = Get_Expenses.expenses_List.OrderByDescending(x => x.Value).ToDictionary(x => x.Key, x => x.Value);
            return Get_Expenses.expenses_List;
        }
    }
}
