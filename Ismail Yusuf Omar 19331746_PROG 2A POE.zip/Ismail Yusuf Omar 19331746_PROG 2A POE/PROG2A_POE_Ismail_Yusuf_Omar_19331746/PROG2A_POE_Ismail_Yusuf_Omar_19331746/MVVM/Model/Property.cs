﻿using PROG2A_POE_Ismail_Yusuf_Omar_19331746.Core;
using System;

namespace PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.Model
{
    public class Property : ObservableObject //update values in view when change using INotifyPropertyChanged
    {
        #region Declare values 
        private double purchase_Price;
        private double deposit;
        private double interest_Rate;
        private int repay_Months;
        #endregion

        #region Get and Set Methods 
        public double Purchase_Price
        {
            get { return purchase_Price; }
            set
            {
                purchase_Price = value;
                OnPropertChanged("Purchase_Price");
            }
        }
        public double Deposit
        {
            get { return deposit; }
            set
            {
                deposit = value;
                OnPropertChanged("Deposit");
            }
        }
        public double Interest_Rate
        {
            get { return interest_Rate; }
            set
            {
                interest_Rate = value;
                OnPropertChanged("Interest_Rate");
            }
        }
        public int Repay_Months
        {
            get { return repay_Months; }
            set
            {
                repay_Months = value;
                OnPropertChanged("Repay_Months");
            }
        }
        #endregion

        public double Home_Loan()  // calculates Home_Loan repayment of property based on user inputed terms 
        {
            double loan_Amount = Purchase_Price - Deposit;
            Interest_Rate = Interest_Rate / 100;
            double repayment = (loan_Amount * ((Interest_Rate / 12) * Math.Pow((1 + (Interest_Rate / 12)), Repay_Months)) /
                                (Math.Pow((1 + (Interest_Rate / 12)), Repay_Months) - 1));
            // calculates Home Loan repayment based on user inputed terms 
            return repayment;

        }
        //get and set for Home_Loan
        public double Get_Home_Loan
        {
            get { return Home_Loan(); }
            set
            {
                Home_Loan();
                OnPropertChanged();
            }
        }

        //reset all values 
        public void Reset()
        {
            purchase_Price = 0;
            deposit = 0;
            interest_Rate = 0;
            repay_Months = 0;
        }

    }
}
