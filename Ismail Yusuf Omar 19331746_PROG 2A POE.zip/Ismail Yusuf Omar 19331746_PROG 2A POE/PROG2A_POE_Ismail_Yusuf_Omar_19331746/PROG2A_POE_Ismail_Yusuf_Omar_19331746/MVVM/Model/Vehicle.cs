﻿using PROG2A_POE_Ismail_Yusuf_Omar_19331746.Core;
using System;

namespace PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.Model
{
    public class Vehicle : ObservableObject //update values in view when change using INotifyPropertyChanged
    {
        #region Declare values 
        private string make = "";
        private string model = "";
        private double price = 0;
        private double deposit = 0;
        private double interest = 0;
        private double insurance = 0;
        #endregion

        #region Get and Set Methods 
        public string Make
        {
            get { return make; }
            set
            {
                make = value;
                OnPropertChanged("Make");
            }
        }
        public string Model
        {
            get { return model; }
            set
            {
                model = value;
                OnPropertChanged("Model");
            }
        }

        public double Price
        {
            get { return price; }
            set
            {
                price = value;
                OnPropertChanged("Price");
            }
        }

        public double Deposit
        {
            get { return deposit; }
            set
            {
                deposit = value;
                OnPropertChanged("Deposit");
            }
        }

        public double Interest
        {
            get { return interest; }
            set
            {
                interest = value;
                OnPropertChanged("Interest");
            }
        }
        public double Insurance
        {
            get { return insurance; }
            set
            {
                insurance = value;
                OnPropertChanged("Insurance");
            }
        }
        #endregion

        public double Monthly_Cost() // calculates Monthly_Cost repayment of vehicle based on user inputed terms 
        {
            double vehicle_Loan = Price - Deposit;
            double vehicle_Interest = Interest / 100;
            double monthly_Cost = Insurance + (vehicle_Loan * (vehicle_Interest / 12 * Math.Pow(1 + (vehicle_Interest / 12), (5 * 12))
                                  / (Math.Pow(1 + (vehicle_Interest / 12), 5 * 12) - 1)));

            return monthly_Cost;
        }
        //get and set for Monthly_Cost
        public double Get_Monthly_Cost
        {
            get { return Monthly_Cost(); }
            set
            {
                Monthly_Cost();
                OnPropertChanged();
            }
        }

        //reset all values 
        public void Reset()
        {
            make = "";
            model = "";
            price = 0;
            deposit = 0;
            interest = 0;
            insurance = 0;
        }
    }
}
