﻿using PROG2A_POE_Ismail_Yusuf_Omar_19331746.Core;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PROG2A_POE_Ismail_Yusuf_Omar_19331746.MVVM.Model
{
    public class Expenses : ObservableObject //update values in view when change using INotifyPropertyChanged
    {
        public Dictionary<string, double> expenses_List { get; set; } = new();
        // declare  Dictionary with get and get 

        #region Declare values 
        private double gross_Income = 0;
        private double tax = 0;
        private double groceries = 0;
        private double water_Lights = 0;
        private double travel = 0;
        private double phone = 0;
        private double other = 0;
        private double living = 0;
        private double rent = 0;
        private double vehicle = 0;
        private double save = 0;
        #endregion

        #region Get and Set Methods 
        public double Gross_Income // get and set Gross_Income
        {
            get { return gross_Income; }
            set
            {
                gross_Income = Convert.ToDouble(value);
                OnPropertChanged(nameof(Gross_Income));
            }
        }
        public double Tax
        {
            get { return tax; }
            set
            {
                tax = Convert.ToDouble(value);
                if (expenses_List.ContainsKey("Tax")) // user has option to enter different property values
                {                                     //resulting in perviouly entered value needing to be overwriten 
                    expenses_List["Tax"] = tax;
                }
                else
                {
                    expenses_List.Add("Tax", tax);// saves user input in Dictionary   
                }
                OnPropertChanged(nameof(Tax));
            }
        }
        public double Groceries
        {
            get { return groceries; }
            set
            {
                groceries = Convert.ToDouble(value);
                if (expenses_List.ContainsKey("Groceries expense")) //user has option to enter different property values
                {                                                 //resulting in perviouly entered value needing to be overwriten 
                    expenses_List["Groceries expense"] = groceries;
                }
                else
                {
                    expenses_List.Add("Groceries expense", groceries);// saves user input in Dictionary   
                }
                OnPropertChanged(nameof(Groceries));
            }
        }
        public double Water_Lights
        {
            get { return water_Lights; }
            set
            {
                water_Lights = Convert.ToDouble(value);
                if (expenses_List.ContainsKey("Water and lights expense")) //user has option to enter different property values
                {                                                 //resulting in perviouly entered value needing to be overwriten 
                    expenses_List["Water and lights expense"] = water_Lights;
                }
                else
                {
                    expenses_List.Add("Water and lights expense", water_Lights);// saves user input in Dictionary   
                }
                OnPropertChanged(nameof(Water_Lights));
            }
        }
        public double Travel
        {
            get { return travel; }
            set
            {
                travel = value;
                if (expenses_List.ContainsKey("Travel expense")) //user has option to enter different property values
                {                                                 //resulting in perviouly entered value needing to be overwriten 
                    expenses_List["Travel expense"] = travel;
                }
                else
                {
                    expenses_List.Add("Travel expense", travel);// saves user input in Dictionary   
                }
                OnPropertChanged(nameof(Travel));
            }
        }
        public double Phone
        {
            get { return phone; }
            set
            {
                phone = Convert.ToDouble(value);
                if (expenses_List.ContainsKey("Phone expense")) //user has option to enter different property values
                {                                                 //resulting in perviouly entered value needing to be overwriten 
                    expenses_List["Phone expense"] = phone;
                }
                else
                {
                    expenses_List.Add("Phone expense", phone);// saves user input in Dictionary   
                }
                OnPropertChanged(nameof(Phone));
            }
        }
        public double Other
        {
            get { return other; }
            set
            {
                other = Convert.ToDouble(value);
                if (expenses_List.ContainsKey("Other expense")) //user has option to enter different property values
                {                                                 //resulting in perviouly entered value needing to be overwriten 
                    expenses_List["Other expense"] = other;
                }
                else
                {
                    expenses_List.Add("Other expense", other);// saves user input in Dictionary   
                }
                OnPropertChanged(nameof(Other));
            }
        }
        public double Living
        {
            get { return living; }
            set
            {
                living = Convert.ToDouble(value);
                if (expenses_List.ContainsKey("Home Loan expense")) //user has option to enter different property values
                {                                                 //resulting in perviouly entered value needing to be overwriten 
                    expenses_List["Home Loan expense"] = living;
                }
                else
                {
                    expenses_List.Add("Home Loan expense", living);// saves user input in Dictionary   
                }
                OnPropertChanged(nameof(Living));
            }
        }

        public double Rent
        {
            get { return rent; }
            set
            {
                rent = Convert.ToDouble(value);
                if (expenses_List.ContainsKey("Rent expense")) // user has option to enter different property values
                {                                                 //resulting in perviouly entered value needing to be overwriten 
                    expenses_List["Rent expense"] = rent;
                }
                else
                {
                    expenses_List.Add("Rent expense", rent);// saves user input in Dictionary   
                }
                OnPropertChanged(nameof(Rent));
            }
        }
        public double Vehicle
        {
            get { return vehicle; }
            set
            {
                vehicle = Convert.ToDouble(value);
                if (expenses_List.ContainsKey("Vehicle expense")) //user has option to enter different property values
                {                                                 //resulting in perviouly entered value needing to be overwriten 
                    expenses_List["Vehicle expense"] = vehicle;
                }
                else
                {
                    expenses_List.Add("Vehicle expense", vehicle);// saves user input in Dictionary   
                }
                OnPropertChanged(nameof(Vehicle));
            }
        }
        public double Save
        {
            get { return save; } //get and set user save amount
            set
            {
                save = Convert.ToDouble(value);
                OnPropertChanged(nameof(Save));
            }

        }

        private DateTime end_Date = DateTime.Now; //initaile date equal to today
        public DateTime End_Date //get and set user inputed end date
        {
            get { return end_Date; }
            set
            {
                end_Date = value;
                OnPropertChanged();

            }
        }
        #endregion

        public DateTime today = DateTime.Now; //set todays date using DateTime

        public void Save_Monthly(double Save, DateTime End) //calculates number of months between today and selected date
                                                            //then calculates monthly amount to save and adds to Dictionary
        {
            int number_Of_Months = (End.Year - today.Year) * 12 + End.Month - today.Month;
            Save = Save / number_Of_Months;
            string save_Key = "Save Monthly for " + number_Of_Months.ToString() + " months";

            if (expenses_List.ContainsKey(save_Key))// user has option to enter different property values
            {                                       //resulting in perviouly entered value needing to be overwriten 
                expenses_List[save_Key] = Save;
            }
            else
            {
                expenses_List.Add(save_Key, Save);
            }
            OnPropertChanged("Save");
        }

        public double Monthly_Excess()
        {
            double excess = Gross_Income - expenses_List.Sum(v => v.Value);
            // calculates Monthly Excess to be returned in final input 
            return excess;
        }

        public void Get_Sum(Check_Total check_Total) //calculates the total of all the expenses the user entered 
        {
            double expenses_Sum = expenses_List.Sum(v => v.Value);
            check_Total(expenses_Sum);//send total back using delegate
        }

        public delegate void Check_Total(double check_Total); //declare delegate pointing to check_Total

        public double Get_Excess //get and set for Monthly_Excess
        {
            get { return Monthly_Excess(); }
            set
            {
                Monthly_Excess();
                OnPropertChanged();
            }

        }


        public void Reset() // restes all values and Dictionary
        {
            expenses_List = new();

            gross_Income = 0;
            tax = 0;
            groceries = 0;
            water_Lights = 0;
            travel = 0;
            phone = 0;
            other = 0;
            living = 0;
            rent = 0;
            vehicle = 0;
            save = 0;
            end_Date = DateTime.Now;
    }
    }

}

